function lim=minmax(a)
%function to determine range of values in matrix A
%USAGE:  lim=minmax(A)
%  lim= two element vector containing [min(A),max(A)] over all matrix
%  dimensions.
%see also MIN, MAX
n=ndims(a);
a1=min(a);
a2=max(a);
for k=2:n,
    a1=min(a1);
    a2=max(a2);
end
lim=[a1,a2];
